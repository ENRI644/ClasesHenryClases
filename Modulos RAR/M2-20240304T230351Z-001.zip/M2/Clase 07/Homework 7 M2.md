![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

## Homework

1. ¿Cuantas carreas tiene Henry?
2. ¿Cuantos alumnos hay en total?
3. ¿Cuantos alumnos tiene cada cohorte?
4. Confecciona un listado de los alumnos ordenado por los últimos alumnos que ingresaron, con nombre y apellido en un solo campo.
5. ¿Cual es el nombre del primer alumno que ingreso a Henry?
6. ¿En que fecha ingreso?
7. ¿Cual es el nombre del ultimo alumno que ingreso a Henry?
8. La función YEAR le permite extraer el año de un campo date, utilice esta función y especifique cuantos alumnos ingresarona a Henry por año.
9. ¿Cuantos alumnos ingresaron por semana a henry?, indique también el año. WEEKOFYEAR()
10. ¿En que años ingresaron más de 20 alumnos?
11. Investigue las funciones TIMESTAMPDIFF() y CURDATE(). ¿Podría utilizarlas para saber cual es la edad de los instructores?. ¿Como podrías verificar si la función cálcula años completos? Utiliza DATE_ADD().
12. Cálcula:<br>
            - La edad de cada alumno.<br>
            - La edad promedio de los alumnos de henry.<br>
            - La edad promedio de los alumnos de cada cohorte.<br>
13. Elabora un listado de los alumnos que superan la edad promedio de Henry.

![ORDEN](/_src/assets/SQL.PNG)
